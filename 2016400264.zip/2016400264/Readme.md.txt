************** STORAGE MANAGER IMPLEMENTATION ***********

The only code file is the storageManager.py which is located under src folder.

The other file is the report file which explains the implementation details.

Run as "python3 storageManager.py input.txt output.txt"

input.txt is the file which consists of database queries

output.txt will be the result file which consists of the results of the given queries.

Contact for any question: fatih.iver@boun.edu.tr